def count_words(text):
    words = text.split()
    return len(words)


