def print_text():
    return "Print some text!"