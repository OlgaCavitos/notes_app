from import_json import upload_phonebook, save_phonebook

def delete_contact(phone_number):
    book = upload_phonebook()
